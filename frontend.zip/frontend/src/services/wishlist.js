export { getWishlist as list, toggleWishlist as toggle } from './catalog'
