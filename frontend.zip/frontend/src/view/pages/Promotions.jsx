export default function Promotions(){
  return (
    <div className="container px-4 py-10">
      <h1 className="text-3xl font-bold mb-6">Khuyến mãi</h1>
      <p>Đang cập nhật các chương trình ưu đãi…</p>
    </div>
  )
}
