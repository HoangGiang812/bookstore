export const ORDER_STATUS = ['pending','processing','shipped','delivered','cancelled'];
export const PAYMENT_METHODS = ['COD','ONLINE'];
